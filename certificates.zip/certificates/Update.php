<?php
include 'connet.php';
session_start();

header('Content-Type: image/jpeg');

$font="font/Certificate.TTF";
$font2="font/futur.TTF";
$font3="font/ITCEDSCR.TTF";
$font4="font/Jaaklightssk.TTF";
$font5="font/SnellBoldBT.TTF";
$font6="font/tahoma.TTF";
$font7="font/tahomabd.TTF";
$image1=imagecreatefromjpeg("certificates.jpg");

$color=imagecolorallocate($image1, 19, 21, 22);
$color2=imagecolorallocate($image1, 159, 0, 0);
$color3=imagecolorallocate($image1, 37, 211, 102);

$id=$_POST['id'];
$name=$_POST['Name'];
$Date2=$_POST['Date2'];
$Registration=$_POST['Registration'];
$Center=$_POST['Center'];
$Father=$_POST['Father'];
$Mother=$_POST['Mother'];
$College=$_POST['College'];
$GPA=$_POST['GPA'];
$Date=$_POST['Date'];
$Serial=$_POST['Serial'];
$Seit=$_POST['Seit'];
$old_img=$_POST['img'];
$old_pdf=$_POST['pdf'];

imagettftext($image1, 250, 0, 4250, 3080, $color, $font3, $name);
imagettftext($image1, 140, 0,1350, 1680, $color2, $font2, $Serial);
imagettftext($image1, 140, 0,1350, 2380, $color3, $font6, $Seit);
imagettftext($image1, 170, 0,1200, 2050, $color, $font4, $Registration);
imagettftext($image1, 250, 0,4000, 4180, $color, $font5, $Center);
imagettftext($image1, 250, 0,4250, 3450, $color, $font3, $Father);
imagettftext($image1, 250, 0,4250, 3790, $color, $font3, $Mother);
imagettftext($image1, 250, 0,4500, 5250, $color, $font, $College);
imagettftext($image1, 250, 0,4880, 5580, $color, $font3, $GPA);
imagettftext($image1, 250, 0,3050, 4890, $color, $font3, $Date);
imagettftext($image1, 250, 0,6200, 4890, $color, $font3, $Date2);


$file=time();
$file_path=("img/".$file.".jpg");
$file_path_pdf=("pdf/".$file.".pdf");

imagejpeg($image1,$file_path);
imagedestroy($image1);

require('fpdf.php');
$pdf=new FPDF();
$pdf->AddPage();
$pdf->Image($file_path,0,0,210,150);
$pdf->Output($file_path_pdf,"F");

 // header('Content-type:application.pdf');
 // header('Content-Disposition: inline; filename"' . $file_path_pdf .'"');
 // header('Content-Transfer-Encoding: binary');
 // header('Accept-Ranges: bytes');
 // @readfile($file_path_pdf);

 $update=mysqli_query($conn,"UPDATE certificate SET Name='$name',Date2='$Date2',Registration='$Registration',Center='$Center',Father='$Father',Mother='$Mother',College='$College',GPA='$GPA',Date='$Date',Serial='$Serial' ,img='$file_path',pdf='$file_path_pdf',Seit='$Seit'  WHERE id='$id'");

unlink("$old_pdf");
unlink("$old_img");

$_SESSION['status'] ="Successful";
$_SESSION['status_dec'] ="Update Successful.";
$_SESSION['status_code'] ="success";
header('Location: list.php');

?>