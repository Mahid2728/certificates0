<?php
include 'connet.php';
session_start();
$id=$_POST['id'];

$old_img=$_POST['img'];
$old_pdf=$_POST['pdf'];

unlink("$old_pdf");
unlink("$old_img");

            $sql = "DELETE FROM certificate WHERE id='$id' ";

				if (mysqli_query($conn, $sql)) {
							$_SESSION['status'] ="Successful";
					    	$_SESSION['status_dec'] ="Removed Successful.";
					    	$_SESSION['status_code'] ="success";
							header('Location: list.php');
				} else {
				  echo "Error deleting record: " . mysqli_error($conn);
				}
        ?>