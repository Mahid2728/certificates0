<?php
include 'connet.php';
session_start();
header('Content-Type: image/jpeg');




//-----------------------------------------
if(isset($_POST['submit'])){

$id=$_POST['id'];
$old_img=$_POST['img'];
$old_pdf=$_POST['pdf'];


$file=$_FILES['file'];
      $_FILES['file']['name'];
      $size=$_FILES['file']['size'];
      $temp=$_FILES['file']['tmp_name'];
      $type=$_FILES['file']['type'];
      $profile_name=$_FILES['file']['name'];

      $destinationfile= 'upload/' .$profile_name;
      move_uploaded_file($temp, $destinationfile);

        
$image = "$old_img";
$image2 = "$destinationfile";

$width = 720;
$height = 720;

// list($width,$height) = getimagesize($image2);

$image = imagecreatefromstring(file_get_contents($image));
$image2 = imagecreatefromstring(file_get_contents($image2));

imagecopymerge($image, $image2, 2500, 6850, 0, 0, $width, $height, 100);


$file=time();
$file_path=("img/".$file.".jpg");
$file_path_pdf=("pdf/".$file.".pdf");

imagejpeg($image,$file_path);
imagedestroy($image);


require('fpdf.php');
$pdf=new FPDF();
$pdf->AddPage();
$pdf->Image($file_path,0,0,210,150);
$pdf->Output($file_path_pdf,"F");


unlink("$old_pdf");
unlink("$old_img");
unlink("$destinationfile");

 $update=mysqli_query($conn,"UPDATE certificate SET img='$file_path',pdf='$file_path_pdf',file='$destinationfile'  WHERE id='$id'");

    $_SESSION['status'] ="Successful";
    $_SESSION['status_dec'] ="QR Code added Successful.";
    $_SESSION['status_code'] ="success";
    header('Location: list.php');


}

?>