<?php
include 'connet.php';
session_start();
header('Content-Type: image/jpeg');

$name=$_POST['Name'];
$Date2=$_POST['Date2'];
$Registration=$_POST['Registration'];
$Center=$_POST['Center'];
$Father=$_POST['Father'];
$Mother=$_POST['Mother'];
$College=$_POST['College'];
$GPA=$_POST['GPA'];
$Date=$_POST['Date'];
$Serial=$_POST['Serial'];
$Seit=$_POST['Seit'];
// $file=$_FILES['file'];
//       $_FILES['file']['name'];
//       $size=$_FILES['file']['size'];
//       $temp=$_FILES['file']['tmp_name'];
//       $type=$_FILES['file']['type'];
//       $profile_name=$_FILES['file']['name'];

//       $destinationfile= 'upload/' .$profile_name;
//       move_uploaded_file($temp, $destinationfile);

// $file_path=("img/".$file.".jpg");

// $image = "certificates.jpg";
// $image2 = "$destinationfile";

// $width = 720;
// $height = 720;

// // list($width,$height) = getimagesize($image2);

// $image = imagecreatefromstring(file_get_contents($image));
// $image2 = imagecreatefromstring(file_get_contents($image2));

// imagecopymerge($image, $image2, 2500, 6850, 0, 0, $width, $height, 100);

// imagejpeg($image,$file_path);


//-----------------------------------------
if(isset($_POST['submit'])){

if (empty($name) or empty($Date2) or empty($Registration) or empty($Center) or empty($Father) or empty($Mother) or empty($College) or empty($GPA) or empty($Date) or empty($Serial)) {

    // header('Location: index.php?error=1');
    $_SESSION['status'] ="error";
    $_SESSION['status_dec'] ="Please Enter The Data Correctly.";
    $_SESSION['status_code'] ="error";
    header('Location: index.php');


}else {
        
$font="font/Certificate.TTF";
$font2="font/futur.TTF";
$font3="font/ITCEDSCR.TTF";
$font4="font/Jaaklightssk.TTF";
$font5="font/SnellBoldBT.TTF";
$font6="font/tahoma.TTF";
$font7="font/tahomabd.TTF";


$image1=imagecreatefromjpeg("certificates.jpg");
$color=imagecolorallocate($image1, 19, 21, 22);
$color2=imagecolorallocate($image1, 159, 0, 0);
$color3=imagecolorallocate($image1, 37, 211, 102);


imagettftext($image1, 250, 0, 4250, 3080, $color, $font3, $name);
imagettftext($image1, 140, 0,1350, 1680, $color2, $font2, $Serial);
imagettftext($image1, 140, 0,1350, 2380, $color3, $font6, $Seit);
imagettftext($image1, 170, 0,1200, 2050, $color, $font4, $Registration);
imagettftext($image1, 250, 0,4000, 4180, $color, $font5, $Center);
imagettftext($image1, 250, 0,4250, 3450, $color, $font3, $Father);
imagettftext($image1, 250, 0,4250, 3790, $color, $font3, $Mother);
imagettftext($image1, 250, 0,4500, 5250, $color, $font, $College);
imagettftext($image1, 250, 0,4880, 5580, $color, $font3, $GPA);
imagettftext($image1, 250, 0,3050, 4890, $color, $font3, $Date);
imagettftext($image1, 250, 0,6200, 4890, $color, $font3, $Date2);



$file=time();
$file_path=("img/".$file.".jpg");
$file_path_pdf=("pdf/".$file.".pdf");

imagejpeg($image1,$file_path);
imagedestroy($image1);


require('fpdf.php');
$pdf=new FPDF();
$pdf->AddPage();
$pdf->Image($file_path,0,0,210,150);
$pdf->Output($file_path_pdf,"F");


 $q="INSERT INTO `certificate`(`Name`, `Date2`, `Registration`, `Center`, `Father`, `Mother`, `College`, `GPA`, `Date`, `Serial`, `img`, `pdf`,`Seit`) 
 VALUES ('$name', '$Date2','$Registration','$Center','$Father','$Mother','$College','$GPA','$Date','$Serial','$file_path','$file_path_pdf','$Seit')";

$query = mysqli_query($conn, $q);

    $_SESSION['status'] ="Successful";
    $_SESSION['status_dec'] ="Certificate Created Successful.";
    $_SESSION['status_code'] ="success";
    header('Location: index.php');

}


}

?>